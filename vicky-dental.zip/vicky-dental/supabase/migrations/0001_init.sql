-- Tabla de turnos del consultorio
create extension if not exists pgcrypto;

create table if not exists public.appointments (
  id           uuid primary key default gen_random_uuid(),
  patient_name text not null,
  phone        text not null,
  reason       text not null,
  urgency      text not null default 'normal'
               check (urgency in ('normal','prioritario','urgente')),
  starts_at    timestamptz not null,
  status       text not null default 'confirmado'
               check (status in ('confirmado','atendido','ausente','cancelado')),
  notes        text,
  created_at   timestamptz not null default now()
);

-- Evita que dos pacientes reserven el mismo horario (los cancelados no cuentan)
create unique index if not exists appointments_slot_unique
  on public.appointments (starts_at) where status <> 'cancelado';

create index if not exists appointments_starts_at_idx
  on public.appointments (starts_at);

-- Seguridad: RLS activado y SIN políticas => nadie con la clave pública puede leer ni escribir.
-- Solo las funciones del servidor (Cloudflare) acceden con la service_role key.
alter table public.appointments enable row level security;
