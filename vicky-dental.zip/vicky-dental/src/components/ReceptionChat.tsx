import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { Send } from "lucide-react";
import { chat, type Msg } from "../lib/api";
import { clinic } from "../lib/clinic";

const greeting: Msg = {
  role: "assistant",
  content: `¡Hola! Soy ${clinic.agentName}, la recepcionista de **${clinic.name}**. Contame qué te está pasando o qué tratamiento buscás y te consigo un turno. 🦷`,
};

const quick = ["Me duele una muela", "Quiero una limpieza", "¿Qué horarios tienen?", "Consulta por ortodoncia"];

export function ReceptionChat() {
  const [messages, setMessages] = useState<Msg[]>([greeting]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function send(raw?: string) {
    const content = (raw ?? text).trim();
    if (!content || loading) return;
    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages(next);
    setText("");
    setLoading(true);
    try {
      const reply = await chat(next.slice(1)); // sin el saludo inicial
      setMessages([...next, { role: "assistant", content: reply }]);
    } catch {
      setMessages([...next, { role: "assistant", content: "Hubo un problema de conexión. Probá de nuevo." }]);
    } finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  }

  return (
    <div className="flex h-[620px] flex-col overflow-hidden rounded-[28px] bg-ink text-white shadow-[0_30px_80px_-20px_rgba(11,31,58,.55)] ring-1 ring-white/10">
      <div className="flex items-center gap-3 border-b border-white/10 bg-ink-2/70 px-5 py-4 backdrop-blur">
        <div className="relative flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-mint to-mint-deep text-xl">
          🦷
          <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-ink-2 bg-whatsapp" aria-hidden />
        </div>
        <div>
          <p className="font-display text-lg font-bold leading-tight">{clinic.agentName}</p>
          <p className="text-xs text-white/60">Recepción de {clinic.name} · en línea</p>
        </div>
      </div>

      <div ref={scroller} className="flex-1 space-y-3 overflow-y-auto px-4 py-5" aria-live="polite">
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
            <div
              className={
                m.role === "user"
                  ? "md max-w-[82%] rounded-2xl rounded-br-md bg-gradient-to-br from-mint to-[#1fb9a5] px-4 py-2.5 text-sm font-medium text-ink"
                  : "md max-w-[88%] rounded-2xl rounded-bl-md bg-white/10 px-4 py-2.5 text-sm leading-relaxed text-white/95"
              }
            >
              <ReactMarkdown>{m.content}</ReactMarkdown>
            </div>
          </div>
        ))}

        {messages.length === 1 && (
          <div className="flex flex-wrap gap-2 pt-1">
            {quick.map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                className="rounded-full border border-mint/40 px-3.5 py-1.5 text-sm text-mint transition hover:bg-mint hover:text-ink"
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {loading && (
          <div className="flex justify-start">
            <div className="rounded-2xl rounded-bl-md bg-white/10 px-4 py-3 text-white/70" aria-label={`${clinic.agentName} está escribiendo`}>
              <span className="dot" /> <span className="dot" /> <span className="dot" />
            </div>
          </div>
        )}
      </div>

      <form
        className="flex items-end gap-2 border-t border-white/10 bg-ink-2/50 p-3"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <textarea
          ref={inputRef}
          rows={1}
          value={text}
          maxLength={500}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          placeholder="Escribí tu mensaje…"
          className="max-h-32 flex-1 resize-none rounded-xl border border-white/15 bg-white/5 px-3.5 py-2.5 text-sm text-white placeholder:text-white/40 focus:border-mint focus:outline-none"
        />
        <button
          type="submit"
          disabled={loading || !text.trim()}
          aria-label="Enviar mensaje"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-mint text-ink transition hover:brightness-110 disabled:opacity-30"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
