// Configuración del consultorio: editar este archivo para cada cliente nuevo.
export const clinic = {
  agentName: "Vicky",
  name: "Consultorio Dental Sonrisa",
  doctor: "Dra. Laura Gómez",
  address: "Av. Corrientes 1234, CABA",
  // Número de WhatsApp del consultorio/dentista (formato internacional sin +)
  whatsapp: "5491168521226",
  whatsappDisplay: "+54 9 11 6852-1226",
  timezone: "America/Argentina/Buenos_Aires",
  timezoneOffset: "-03:00",
  slotMinutes: 30,
  // 0=domingo ... 6=sábado ; bloques en hora local
  hours: {
    1: [["09:00", "13:00"], ["15:00", "19:00"]],
    2: [["09:00", "13:00"], ["15:00", "19:00"]],
    3: [["09:00", "13:00"], ["15:00", "19:00"]],
    4: [["09:00", "13:00"], ["15:00", "19:00"]],
    5: [["09:00", "13:00"], ["15:00", "19:00"]],
    6: [["09:00", "13:00"]],
  } as Record<number, [string, string][]>,
  hoursText: "Lun a Vie 9–13 y 15–19 · Sáb 9–13",
  services: [
    "Consulta y diagnóstico",
    "Limpieza dental",
    "Arreglos / caries",
    "Tratamiento de conducto",
    "Extracciones",
    "Blanqueamiento",
    "Ortodoncia",
    "Implantes",
    "Urgencias (dolor, golpe, inflamación)",
  ],
  insurance: "Atendemos OSDE, Swiss Medical, Galeno y particulares.",
};

export function waLink(text: string, phone = clinic.whatsapp) {
  return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
}

function toMin(t: string) {
  const [h = 0, m = 0] = t.split(":").map(Number);
  return h * 60 + m;
}
function fmt(m: number) {
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}

export function isValidDate(date: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(new Date(`${date}T12:00:00Z`).getTime());
}

/** Todos los horarios posibles (HH:MM) para una fecha YYYY-MM-DD según el horario del consultorio. */
export function slotsForDate(date: string): string[] {
  const day = new Date(`${date}T12:00:00${clinic.timezoneOffset}`).getUTCDay();
  const blocks = clinic.hours[day] ?? [];
  const out: string[] = [];
  for (const [a, b] of blocks) {
    for (let m = toMin(a); m + clinic.slotMinutes <= toMin(b); m += clinic.slotMinutes) out.push(fmt(m));
  }
  return out;
}

export function toIso(date: string, time: string) {
  return new Date(`${date}T${time}:00${clinic.timezoneOffset}`).toISOString();
}

/** Fecha/hora local del consultorio (Argentina no tiene horario de verano: UTC-3 fijo) */
export function localParts(iso: string) {
  const d = new Date(new Date(iso).getTime() - 3 * 3600 * 1000);
  return { date: d.toISOString().slice(0, 10), time: d.toISOString().slice(11, 16) };
}

export function todayLocal() {
  return localParts(new Date().toISOString()).date;
}

export function addDays(date: string, n: number) {
  const d = new Date(`${date}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
