export type Msg = { role: "user" | "assistant"; content: string };

export async function chat(messages: Msg[]): Promise<string> {
  const r = await fetch("/api/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ messages }),
  });
  if (!r.ok) throw new Error("chat failed");
  const data = (await r.json()) as { reply: string };
  return data.reply;
}

export type Appt = {
  id: string;
  patient_name: string;
  phone: string;
  reason: string;
  urgency: string;
  starts_at: string;
  status: string;
  notes: string | null;
  created_at: string;
};

async function panel<T>(body: Record<string, unknown>): Promise<T> {
  const r = await fetch("/api/panel", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  if (r.status === 401) throw new Error("PIN");
  if (!r.ok) throw new Error("error");
  return r.json() as Promise<T>;
}

export const listAppointments = (pin: string, from: string, to: string) =>
  panel<{ rows: Appt[] }>({ action: "list", pin, from, to }).then((d) => d.rows);

export const setAppointmentStatus = (pin: string, id: string, status: string) =>
  panel<{ ok: true }>({ action: "status", pin, id, status });
