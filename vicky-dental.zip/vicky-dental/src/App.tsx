import { useEffect } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import Home from "./pages/Home";
import Panel from "./pages/Panel";
import { clinic } from "./lib/clinic";

export default function App() {
  const { pathname } = useLocation();
  useEffect(() => {
    document.title = pathname.startsWith("/panel") ? `Panel · ${clinic.name}` : `${clinic.name} · Pedí tu turno online`;
  }, [pathname]);
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/panel" element={<Panel />} />
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
