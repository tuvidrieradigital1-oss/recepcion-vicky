import { Link } from "react-router-dom";
import { CalendarCheck, Brain, Ear, FileText, MapPin, Clock, ShieldCheck, MessageCircle } from "lucide-react";
import { ReceptionChat } from "../components/ReceptionChat";
import { clinic, waLink } from "../lib/clinic";

const steps = [
  { icon: Ear, t: "Escucha", d: "Atiende a cada paciente, a cualquier hora, sin esperas." },
  { icon: Brain, t: "Entiende", d: "Detecta el motivo de la consulta y si es una urgencia." },
  { icon: CalendarCheck, t: "Agenda", d: "Ofrece horarios libres reales y reserva el turno." },
  { icon: FileText, t: "Reporta", d: "El consultorio recibe un resumen diario por WhatsApp." },
];

export default function Home() {
  return (
    <div className="relative overflow-hidden">
      {/* fondo */}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 -z-0 h-[900px]">
        <div className="blob absolute -right-40 -top-40 h-[640px] w-[640px] rounded-full bg-mint/30 blur-3xl" />
        <div className="absolute -left-48 top-72 h-[460px] w-[460px] rounded-full bg-[#7aa7ff]/25 blur-3xl" />
      </div>

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="flex items-center gap-2 font-display text-xl font-extrabold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-ink text-lg">🦷</span>
          {clinic.name}
        </span>
        <Link to="/panel" className="rounded-full border border-ink/15 px-4 py-2 text-sm font-semibold transition hover:bg-ink hover:text-white">
          Panel del consultorio
        </Link>
      </header>

      <main className="relative z-10 mx-auto grid max-w-6xl gap-12 px-6 pb-20 pt-6 lg:grid-cols-[1.05fr_1fr] lg:items-start">
        <section>
          <p className="inline-flex items-center gap-2 rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold shadow-sm ring-1 ring-ink/10">
            <span className="h-2 w-2 rounded-full bg-whatsapp" /> {clinic.agentName} está atendiendo ahora
          </p>
          <h1 className="mt-6 text-5xl font-extrabold leading-[1.02] md:text-7xl">
            Tu turno dental, en un mensaje.
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink/70">
            Contale a {clinic.agentName} qué necesitás y te reserva un horario con {clinic.doctor}. Sin llamadas y sin esperar a que abra el consultorio.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#chat"
              className="inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3.5 font-semibold text-white shadow-lg transition hover:bg-ink-2 lg:hidden"
            >
              Hablar con {clinic.agentName}
            </a>
            <a
              href={waLink(`Hola ${clinic.name}, quiero pedir un turno.`)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-whatsapp px-6 py-3.5 font-semibold text-[#06310f] shadow-lg transition hover:brightness-105"
            >
              <MessageCircle className="h-5 w-5" /> Escribinos por WhatsApp
            </a>
          </div>

          {/* datos útiles */}
          <dl className="mt-12 grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-ink/5">
              <MapPin className="h-5 w-5 text-mint-deep" />
              <dt className="mt-2 text-sm font-bold">Dónde estamos</dt>
              <dd className="text-sm text-ink/65">{clinic.address}</dd>
            </div>
            <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-ink/5">
              <Clock className="h-5 w-5 text-mint-deep" />
              <dt className="mt-2 text-sm font-bold">Horarios</dt>
              <dd className="text-sm text-ink/65">{clinic.hoursText}</dd>
            </div>
            <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-ink/5">
              <ShieldCheck className="h-5 w-5 text-mint-deep" />
              <dt className="mt-2 text-sm font-bold">Obras sociales</dt>
              <dd className="text-sm text-ink/65">OSDE, Swiss Medical, Galeno y particulares</dd>
            </div>
          </dl>

          <h2 className="mt-14 text-2xl font-bold">Cómo funciona</h2>
          <div className="mt-5 grid grid-cols-2 gap-4">
            {steps.map((s) => (
              <div key={s.t} className="rounded-2xl bg-ink p-5 text-white">
                <s.icon className="h-5 w-5 text-mint" />
                <p className="mt-3 font-display text-lg font-bold">{s.t}</p>
                <p className="mt-1 text-sm text-white/65">{s.d}</p>
              </div>
            ))}
          </div>

          <h2 className="mt-14 text-2xl font-bold">Tratamientos</h2>
          <ul className="mt-4 flex flex-wrap gap-2">
            {clinic.services.map((s) => (
              <li key={s} className="rounded-full bg-white px-4 py-2 text-sm font-medium ring-1 ring-ink/10">
                {s}
              </li>
            ))}
          </ul>
        </section>

        <section id="chat" className="scroll-mt-6 lg:sticky lg:top-6">
          <div className="relative">
            <div aria-hidden className="absolute -left-6 -top-6 hidden rounded-2xl bg-white px-4 py-3 text-sm font-semibold shadow-xl ring-1 ring-ink/10 xl:block">
              ✅ Turno confirmado · Jue 10:30
            </div>
            <ReceptionChat />
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-ink/10 px-6 py-8 text-center text-sm text-ink/55">
        {clinic.name} · {clinic.address} · {clinic.whatsappDisplay}
      </footer>
    </div>
  );
}
