import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, MessageCircle, RefreshCw } from "lucide-react";
import { listAppointments, setAppointmentStatus, type Appt } from "../lib/api";
import { addDays, clinic, localParts, todayLocal, toIso, waLink } from "../lib/clinic";

export default function Panel() {
  const [pin, setPin] = useState("");
  const [authed, setAuthed] = useState(false);
  const [date, setDate] = useState("");
  const [rows, setRows] = useState<Appt[]>([]);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setDate(todayLocal());
    const saved = sessionStorage.getItem("panel_pin");
    if (saved) {
      setPin(saved);
      setAuthed(true);
    }
  }, []);

  async function load(p = pin, d = date) {
    if (!d) return;
    setLoading(true);
    setErr("");
    try {
      const r = await listAppointments(p, toIso(d, "00:00"), toIso(addDays(d, 7), "23:59"));
      setRows(r);
      setAuthed(true);
      sessionStorage.setItem("panel_pin", p);
    } catch (e) {
      setErr(e instanceof Error && e.message === "PIN" ? "PIN incorrecto" : "No se pudo cargar");
      setAuthed(false);
      sessionStorage.removeItem("panel_pin");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (authed && date) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authed, date]);

  const today = rows.filter((r) => localParts(r.starts_at).date === date);
  const active = today.filter((r) => r.status !== "cancelado");
  const urgent = active.filter((r) => r.urgency !== "normal");
  const newToday = rows.filter((r) => localParts(r.created_at).date === date);
  const upcoming = rows.filter((r) => localParts(r.starts_at).date > date && r.status !== "cancelado");

  const report = useMemo(
    () =>
      [
        `📋 *Resumen ${date}* – ${clinic.name}`,
        `Turnos del día: ${active.length}${urgent.length ? ` (⚠️ ${urgent.length} urgentes/prioritarios)` : ""}`,
        `Nuevas reservas hechas hoy por ${clinic.agentName}: ${newToday.length}`,
        "",
        ...active.map(
          (r) =>
            `• ${localParts(r.starts_at).time} ${r.patient_name} – ${r.reason}${r.urgency !== "normal" ? ` [${r.urgency.toUpperCase()}]` : ""} (${r.phone})`,
        ),
      ].join("\n"),
    [active, urgent, newToday, date],
  );

  async function changeStatus(id: string, status: string) {
    await setAppointmentStatus(pin, id, status);
    load();
  }

  if (!authed) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink px-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            load(pin);
          }}
          className="w-full max-w-sm rounded-3xl bg-white p-8 shadow-2xl"
        >
          <h1 className="text-3xl font-extrabold">Panel del consultorio</h1>
          <p className="mt-2 text-sm text-ink/60">Ingresá el PIN para ver la agenda.</p>
          <input
            type="password"
            inputMode="numeric"
            autoComplete="current-password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="PIN"
            className="mt-6 w-full rounded-xl border border-ink/15 px-4 py-3 outline-none focus:border-mint-deep"
          />
          {err && <p className="mt-2 text-sm font-medium text-coral">{err}</p>}
          <button disabled={loading} className="mt-4 w-full rounded-xl bg-ink py-3 font-semibold text-white transition hover:bg-ink-2 disabled:opacity-60">
            {loading ? "Entrando…" : "Entrar"}
          </button>
          <Link to="/" className="mt-4 block text-center text-sm text-ink/55 hover:text-ink">Volver al sitio</Link>
        </form>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-8">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-ink/55 hover:text-ink">
        <ArrowLeft className="h-4 w-4" /> Sitio
      </Link>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-ink/55">{clinic.name}</p>
          <h1 className="text-4xl font-extrabold">Agenda y reporte</h1>
        </div>
        <div className="flex items-center gap-2">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-xl border border-ink/15 bg-white px-3 py-2" />
          <button onClick={() => load()} aria-label="Actualizar" className="rounded-xl border border-ink/15 bg-white p-2.5">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Stat label="Turnos del día" value={active.length} tone="ink" />
        <Stat label="Urgentes / prioritarios" value={urgent.length} tone="coral" />
        <Stat label={`Reservas nuevas hoy`} value={newToday.length} tone="mint" />
      </div>

      <section className="mt-6 rounded-3xl bg-ink p-6 text-white">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-2xl font-bold">Resumen diario</h2>
          <a
            href={waLink(report)}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-whatsapp px-5 py-2.5 text-sm font-semibold text-[#06310f]"
          >
            <MessageCircle className="h-4 w-4" /> Enviar al WhatsApp del dentista
          </a>
        </div>
        <pre className="mt-4 whitespace-pre-wrap font-sans text-sm text-white/80">{report}</pre>
      </section>

      <section className="mt-8">
        <h2 className="text-2xl font-bold">Turnos de {date}</h2>
        <List rows={today} onStatus={changeStatus} />
      </section>
      <section className="mt-8">
        <h2 className="text-2xl font-bold">Próximos 7 días</h2>
        <List rows={upcoming} onStatus={changeStatus} showDate />
      </section>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone: "ink" | "coral" | "mint" }) {
  const c = tone === "coral" ? "text-coral" : tone === "mint" ? "text-mint-deep" : "text-ink";
  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-ink/5">
      <p className="text-sm text-ink/60">{label}</p>
      <p className={`mt-1 font-display text-5xl font-extrabold ${c}`}>{value}</p>
    </div>
  );
}

function List({ rows, onStatus, showDate }: { rows: Appt[]; onStatus: (id: string, s: string) => void; showDate?: boolean }) {
  if (!rows.length) return <p className="mt-3 text-sm text-ink/55">Sin turnos.</p>;
  return (
    <div className="mt-3 divide-y divide-ink/10 rounded-2xl bg-white shadow-sm ring-1 ring-ink/5">
      {rows.map((r) => {
        const p = localParts(r.starts_at);
        return (
          <div key={r.id} className="flex flex-wrap items-center gap-4 p-4">
            <div className="w-24 font-display text-xl font-bold">
              {showDate && <span className="block text-xs font-normal text-ink/55">{p.date}</span>}
              {p.time}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold">
                {r.patient_name}{" "}
                {r.urgency !== "normal" && <span className="ml-1 rounded-full bg-coral/15 px-2 py-0.5 text-xs font-semibold text-coral">{r.urgency}</span>}
              </p>
              <p className="text-sm text-ink/60">
                {r.reason} ·{" "}
                <a
                  className="underline"
                  href={waLink(`Hola ${r.patient_name}, te escribimos de ${clinic.name} por tu turno del ${p.date} a las ${p.time}.`, r.phone.replace(/\D/g, ""))}
                  target="_blank"
                  rel="noreferrer"
                >
                  {r.phone}
                </a>
              </p>
              {r.notes && <p className="mt-1 text-xs text-ink/55">{r.notes}</p>}
            </div>
            <select value={r.status} onChange={(e) => onStatus(r.id, e.target.value)} className="rounded-lg border border-ink/15 bg-white px-2 py-1 text-sm">
              <option value="confirmado">Confirmado</option>
              <option value="atendido">Atendido</option>
              <option value="ausente">Ausente</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>
        );
      })}
    </div>
  );
}
