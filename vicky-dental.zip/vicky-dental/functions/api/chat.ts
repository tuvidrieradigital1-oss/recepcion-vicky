import { clinic } from "../../src/lib/clinic";
import { todayLocal } from "../../src/lib/clinic";
import { book, db, freeSlots, json, type Env } from "../_lib/agenda";

type Msg = { role: "user" | "assistant"; content: string };

const tools = [
  {
    name: "get_available_slots",
    description: "Devuelve los horarios libres (HH:MM, hora local) de una fecha. Usala SIEMPRE antes de ofrecer horarios.",
    input_schema: {
      type: "object",
      properties: { date: { type: "string", description: "Fecha en formato YYYY-MM-DD" } },
      required: ["date"],
    },
  },
  {
    name: "book_appointment",
    description: "Reserva el turno. Llamala solo cuando el paciente eligió un horario y ya tenés nombre, teléfono y motivo.",
    input_schema: {
      type: "object",
      properties: {
        patient_name: { type: "string" },
        phone: { type: "string", description: "Teléfono con característica, ej: 11 5555-1234" },
        reason: { type: "string", description: "Motivo de la consulta en pocas palabras" },
        urgency: { type: "string", enum: ["normal", "prioritario", "urgente"] },
        date: { type: "string", description: "YYYY-MM-DD" },
        time: { type: "string", description: "HH:MM, uno de los horarios devueltos por get_available_slots" },
        notes: { type: "string", description: "Detalles útiles para la doctora (opcional)" },
      },
      required: ["patient_name", "phone", "reason", "date", "time"],
    },
  },
];

function systemPrompt() {
  const today = todayLocal();
  const weekday = new Date(`${today}T12:00:00${clinic.timezoneOffset}`).toLocaleDateString("es-AR", {
    weekday: "long",
    timeZone: clinic.timezone,
  });
  const hours = Object.entries(clinic.hours)
    .map(([d, b]) => `${["dom", "lun", "mar", "mié", "jue", "vie", "sáb"][Number(d)]}: ${b.map((x) => x.join("–")).join(" y ")}`)
    .join("; ");
  return `Sos ${clinic.agentName}, la recepcionista virtual de ${clinic.name} (${clinic.doctor}), en ${clinic.address}.
Hablás en español rioplatense (voseo), cálida, clara y breve: mensajes cortos, sin listas largas.

Hoy es ${weekday} ${today} (hora de Argentina).
Horarios de atención: ${hours}. Turnos de ${clinic.slotMinutes} minutos.
Servicios: ${clinic.services.join("; ")}.
Obras sociales: ${clinic.insurance}

Tu trabajo: entender qué necesita el paciente y agendarle un turno.
1. Preguntá el motivo si no lo dijo. Detectá urgencias (dolor fuerte, golpe, inflamación, sangrado, diente roto): marcá urgency "urgente" y ofrecé el primer horario disponible.
2. Pedí la fecha o franja que prefiere. Llamá get_available_slots y ofrecé 3 o 4 opciones concretas, nunca inventes horarios.
3. Pedí nombre completo y teléfono (los necesitás para confirmar).
4. Con todo confirmado, llamá book_appointment. Si falla, ofrecé otras opciones.
5. Al confirmar, repetí día, hora, nombre y dirección.

Reglas: no des diagnósticos ni indiques medicación; ante una emergencia grave (dificultad para respirar o tragar, hinchazón en la cara o el cuello con fiebre) indicá ir a una guardia ya. No des precios si no los tenés: decí que la doctora los confirma en la consulta. Si piden algo fuera del consultorio, volvé amablemente al tema de turnos. Interpretá fechas relativas ("mañana", "el viernes") a partir de la fecha de hoy.`;
}

function clean(raw: unknown): Msg[] {
  if (!Array.isArray(raw)) return [];
  const msgs: Msg[] = raw
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
    .map((m) => ({ role: m.role, content: String(m.content).slice(0, 2000) }));
  const last = msgs.slice(-24);
  while (last.length && last[0].role !== "user") last.shift();
  return last;
}

export const onRequestPost = async ({ request, env }: { request: Request; env: Env }) => {
  let body: { messages?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: "Solicitud inválida" }, 400);
  }
  const history = clean(body.messages);
  if (!history.length) return json({ error: "Sin mensajes" }, 400);

  const client = db(env);
  // deno-lint-ignore no-explicit-any
  const messages: any[] = history.map((m) => ({ role: m.role, content: m.content }));

  try {
    for (let i = 0; i < 6; i++) {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: env.ANTHROPIC_MODEL || "claude-haiku-5-5",
          max_tokens: 700,
          system: systemPrompt(),
          tools,
          messages,
        }),
      });
      if (!res.ok) {
        console.error("Anthropic error", res.status, await res.text());
        return json({ reply: "Tuve un problema técnico. ¿Probás de nuevo en un momento?" });
      }
      const data = (await res.json()) as { stop_reason: string; content: any[] };

      if (data.stop_reason !== "tool_use") {
        const text = data.content.filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
        return json({ reply: text || "¿Me contás un poco más?" });
      }

      messages.push({ role: "assistant", content: data.content });
      const results: any[] = [];
      for (const block of data.content.filter((b) => b.type === "tool_use")) {
        let out: unknown;
        try {
          if (block.name === "get_available_slots") out = { date: block.input.date, slots: await freeSlots(client, block.input.date) };
          else if (block.name === "book_appointment") out = await book(client, block.input);
          else out = { error: "Herramienta desconocida" };
        } catch (e) {
          console.error(e);
          out = { error: "Error interno consultando la agenda" };
        }
        results.push({ type: "tool_result", tool_use_id: block.id, content: JSON.stringify(out) });
      }
      messages.push({ role: "user", content: results });
    }
    return json({ reply: "Se me complicó el pedido. ¿Lo intentamos de nuevo?" });
  } catch (e) {
    console.error(e);
    return json({ reply: "Hubo un problema de conexión. Probá de nuevo." });
  }
};
