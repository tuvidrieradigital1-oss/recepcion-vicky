import { db, json, type Env } from "../_lib/agenda";

const STATUSES = ["confirmado", "atendido", "ausente", "cancelado"];

function pinOk(given: unknown, real: string | undefined) {
  if (!real || typeof given !== "string" || given.length !== real.length) return false;
  let diff = 0;
  for (let i = 0; i < real.length; i++) diff |= given.charCodeAt(i) ^ real.charCodeAt(i);
  return diff === 0;
}

export const onRequestPost = async ({ request, env }: { request: Request; env: Env }) => {
  let body: any;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Solicitud inválida" }, 400);
  }
  if (!pinOk(body.pin, env.PANEL_PIN)) return json({ error: "PIN incorrecto" }, 401);

  const client = db(env);

  if (body.action === "list") {
    const { data, error } = await client
      .from("appointments")
      .select("*")
      .gte("starts_at", String(body.from))
      .lte("starts_at", String(body.to))
      .order("starts_at", { ascending: true });
    if (error) return json({ error: "No se pudo cargar" }, 500);
    return json({ rows: data });
  }

  if (body.action === "status") {
    if (!STATUSES.includes(body.status) || typeof body.id !== "string") return json({ error: "Datos inválidos" }, 400);
    const { error } = await client.from("appointments").update({ status: body.status }).eq("id", body.id);
    if (error) return json({ error: "No se pudo actualizar" }, 500);
    return json({ ok: true });
  }

  return json({ error: "Acción desconocida" }, 400);
};
