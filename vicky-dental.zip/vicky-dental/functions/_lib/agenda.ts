import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { clinic, isValidDate, localParts, slotsForDate, toIso, todayLocal, addDays } from "../../src/lib/clinic";

export type Env = {
  ANTHROPIC_API_KEY: string;
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
  PANEL_PIN: string;
  ANTHROPIC_MODEL?: string;
};

export function db(env: Env): SupabaseClient {
  return createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });
}

export function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

/** Horarios libres de una fecha: horario del consultorio - turnos ya tomados - horas pasadas. */
export async function freeSlots(client: SupabaseClient, date: string): Promise<string[]> {
  if (!isValidDate(date)) return [];
  const today = todayLocal();
  if (date < today || date > addDays(today, 60)) return [];

  const all = slotsForDate(date);
  if (!all.length) return [];

  const { data, error } = await client
    .from("appointments")
    .select("starts_at")
    .neq("status", "cancelado")
    .gte("starts_at", toIso(date, "00:00"))
    .lte("starts_at", toIso(date, "23:59"));
  if (error) throw new Error(error.message);

  const taken = new Set((data ?? []).map((r: { starts_at: string }) => localParts(r.starts_at).time));
  const now = localParts(new Date().toISOString());
  return all.filter((t) => !taken.has(t) && (date > now.date || t > now.time));
}

export type BookInput = {
  patient_name: string;
  phone: string;
  reason: string;
  urgency?: string;
  date: string;
  time: string;
  notes?: string;
};

export async function book(client: SupabaseClient, input: BookInput) {
  const name = String(input.patient_name ?? "").trim().slice(0, 100);
  const phone = String(input.phone ?? "").trim().slice(0, 30);
  const reason = String(input.reason ?? "").trim().slice(0, 200);
  const urgency = ["normal", "prioritario", "urgente"].includes(input.urgency ?? "") ? input.urgency! : "normal";
  if (!name || !phone || !reason) return { ok: false, error: "Faltan datos: nombre, teléfono y motivo son obligatorios." };
  if (phone.replace(/\D/g, "").length < 8) return { ok: false, error: "El teléfono no parece válido." };

  const free = await freeSlots(client, input.date);
  if (!free.includes(input.time)) {
    return { ok: false, error: "Ese horario ya no está disponible.", available: free };
  }

  const { error } = await client.from("appointments").insert({
    patient_name: name,
    phone,
    reason,
    urgency,
    starts_at: toIso(input.date, input.time),
    notes: input.notes ? String(input.notes).slice(0, 300) : null,
  });
  if (error) {
    // 23505 = violación del índice único (alguien reservó justo antes)
    if (error.code === "23505") return { ok: false, error: "Ese horario se acaba de ocupar.", available: await freeSlots(client, input.date) };
    return { ok: false, error: "No se pudo guardar el turno." };
  }
  return { ok: true, date: input.date, time: input.time, patient_name: name, doctor: clinic.doctor, address: clinic.address };
}
